--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.1 (Debian 18.1-1.pgdg13+2)
-- Dumped by pg_dump version 18.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE myhome;
--
-- Name: myhome; Type: DATABASE; Schema: -; Owner: user
--

CREATE DATABASE myhome WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE myhome OWNER TO "user";

\unrestrict (null)
\connect myhome
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: rooms; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.rooms (
    id integer NOT NULL,
    name text
);


ALTER TABLE public.rooms OWNER TO "user";

--
-- Name: rooms_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.rooms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rooms_id_seq OWNER TO "user";

--
-- Name: temperatures; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.temperatures (
    id integer NOT NULL,
    room_id integer,
    temperature real,
    date timestamp without time zone
);


ALTER TABLE public.temperatures OWNER TO "user";

--
-- Name: temperatures_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.temperatures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.temperatures_id_seq OWNER TO "user";

--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.rooms (id, name) FROM stdin;
\.
COPY public.rooms (id, name) FROM '$$PATH$$/3441.dat';

--
-- Data for Name: temperatures; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.temperatures (id, room_id, temperature, date) FROM stdin;
\.
COPY public.temperatures (id, room_id, temperature, date) FROM '$$PATH$$/3443.dat';

--
-- Name: rooms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.rooms_id_seq', 1, false);


--
-- Name: temperatures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.temperatures_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

